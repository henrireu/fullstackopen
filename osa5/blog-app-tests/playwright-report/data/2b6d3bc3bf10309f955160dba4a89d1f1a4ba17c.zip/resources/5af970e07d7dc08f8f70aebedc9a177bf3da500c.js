import {
  require_react
} from "/node_modules/.vite/deps/chunk-7JGOPB4S.js?v=d4a61334";
import "/node_modules/.vite/deps/chunk-6TJCVOLN.js?v=d4a61334";
export default require_react();
//# sourceMappingURL=react.js.map
