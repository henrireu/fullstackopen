import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d4a61334"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=d4a61334"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import Blogs from "/src/components/Blogs.jsx?t=1715156060194";
import AddBlog from "/src/components/AddBlog.jsx";
import blogService from "/src/services/blogs.js";
import loginService from "/src/services/login.js";
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [errorMessage, setErrorMessage] = useState(null);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  useEffect(() => {
    const loggedUser = window.localStorage.getItem("user");
    if (loggedUser) {
      const user2 = JSON.parse(loggedUser);
      setUser(user2);
      blogService.setToken(user2.token);
    }
  }, []);
  useEffect(() => {
    blogService.getAll().then((blogs2) => setBlogs(blogs2));
  }, []);
  const handleLogin = async (event) => {
    event.preventDefault();
    try {
      const user2 = await loginService.login({
        username,
        password
      });
      window.localStorage.setItem("user", JSON.stringify(user2));
      blogService.setToken(user2.token);
      setUser(user2);
      setUsername("");
      setPassword("");
    } catch (exception) {
      setErrorMessage("wrong username or password");
      setTimeout(() => {
        setErrorMessage(null);
      }, 5e3);
    }
  };
  const loginForm = () => /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "log in to application" }, void 0, false, {
      fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/App.jsx",
      lineNumber: 45,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("h2", { className: "errormessage", children: errorMessage }, void 0, false, {
      fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/App.jsx",
      lineNumber: 46,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { "data-testid": "loginform", onSubmit: handleLogin, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        "username",
        /* @__PURE__ */ jsxDEV("input", { "data-testid": "username", type: "text", value: username, name: "Username", onChange: ({
          target
        }) => setUsername(target.value) }, void 0, false, {
          fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/App.jsx",
          lineNumber: 50,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/App.jsx",
        lineNumber: 48,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "password",
        /* @__PURE__ */ jsxDEV("input", { "data-testid": "password", type: "password", value: password, name: "Password", onChange: ({
          target
        }) => setPassword(target.value) }, void 0, false, {
          fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/App.jsx",
          lineNumber: 56,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/App.jsx",
        lineNumber: 54,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { "data-testid": "loginbutton", type: "submit", children: "login" }, void 0, false, {
        fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/App.jsx",
        lineNumber: 60,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/App.jsx",
      lineNumber: 47,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/App.jsx",
    lineNumber: 44,
    columnNumber: 27
  }, this);
  const addBlog = (newBlog) => {
    setBlogs(blogs.concat(newBlog));
  };
  const testi = () => {
    console.log(blogs);
  };
  const logOut = () => {
  };
  const updateBlog = (id, newBlog) => {
    const newBlogs = [];
    for (let x = 0; x < blogs.length; x++) {
      if (blogs.id === id) {
        newBlogs.push(newBlog);
      } else {
        newBlogs.push(blogs[x]);
      }
    }
    setBlogs(newBlogs);
  };
  const deleteBlog = (id) => {
    const newBlogs = blogs.filter((blog) => blog.id !== id);
    setBlogs(newBlogs);
  };
  return /* @__PURE__ */ jsxDEV("div", { children: user === null ? loginForm() : /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(Blogs, { blogs, user, setUser, updateBlog, deleteBlog }, void 0, false, {
      fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/App.jsx",
      lineNumber: 87,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(AddBlog, { blogs, setBlogs, user, addBlog }, void 0, false, {
      fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/App.jsx",
      lineNumber: 88,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/App.jsx",
    lineNumber: 86,
    columnNumber: 38
  }, this) }, void 0, false, {
    fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/App.jsx",
    lineNumber: 85,
    columnNumber: 10
  }, this);
};
_s(App, "sU/Z6+yHLRbhBhTgLr2lN1LBV+8=");
_c = App;
{
}
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdURNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXZETixTQUFTQSxVQUFVQyxpQkFBaUI7QUFDcEMsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxrQkFBa0I7QUFJekIsTUFBTUMsTUFBTUEsTUFBTTtBQUFBQyxLQUFBO0FBQ2hCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJVCxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDVSxjQUFjQyxlQUFlLElBQUlYLFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUNZLFVBQVVDLFdBQVcsSUFBSWIsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ2MsVUFBVUMsV0FBVyxJQUFJZixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDZ0IsTUFBTUMsT0FBTyxJQUFJakIsU0FBUyxJQUFJO0FBR3JDQyxZQUFVLE1BQU07QUFDZCxVQUFNaUIsYUFBYUMsT0FBT0MsYUFBYUMsUUFBUSxNQUFNO0FBQ3JELFFBQUlILFlBQVk7QUFDZCxZQUFNRixRQUFPTSxLQUFLQyxNQUFNTCxVQUFVO0FBQ2xDRCxjQUFRRCxLQUFJO0FBQ1paLGtCQUFZb0IsU0FBU1IsTUFBS1MsS0FBSztBQUFBLElBQ2pDO0FBQUEsRUFDRixHQUFFLEVBQUU7QUFFSnhCLFlBQVUsTUFBTTtBQUNkRyxnQkFBWXNCLE9BQU8sRUFBRUMsS0FBS25CLFlBQ3hCQyxTQUFVRCxNQUFNLENBQ2xCO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTCxRQUFNb0IsY0FBYyxPQUFPQyxVQUFVO0FBQ25DQSxVQUFNQyxlQUFlO0FBRXJCLFFBQUk7QUFDRixZQUFNZCxRQUFPLE1BQU1YLGFBQWEwQixNQUFNO0FBQUEsUUFDcENuQjtBQUFBQSxRQUFVRTtBQUFBQSxNQUNaLENBQUM7QUFDREssYUFBT0MsYUFBYVksUUFDbEIsUUFBUVYsS0FBS1csVUFBVWpCLEtBQUksQ0FDN0I7QUFDQVosa0JBQVlvQixTQUFTUixNQUFLUyxLQUFLO0FBQy9CUixjQUFRRCxLQUFJO0FBQ1pILGtCQUFZLEVBQUU7QUFDZEUsa0JBQVksRUFBRTtBQUFBLElBQ2hCLFNBQVNtQixXQUFXO0FBQ2xCdkIsc0JBQWdCLDRCQUE0QjtBQUM1Q3dCLGlCQUFXLE1BQU07QUFDZnhCLHdCQUFnQixJQUFJO0FBQUEsTUFDdEIsR0FBRyxHQUFJO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFFQSxRQUFNeUIsWUFBWUEsTUFDaEIsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFFBQUcscUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QjtBQUFBLElBQ3pCLHVCQUFDLFFBQUcsV0FBVSxnQkFBZ0IxQiwwQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyQztBQUFBLElBQzNDLHVCQUFDLFVBQUssZUFBWSxhQUFZLFVBQVVrQixhQUN0QztBQUFBLDZCQUFDLFNBQUk7QUFBQTtBQUFBLFFBRUgsdUJBQUMsV0FDQyxlQUFZLFlBQ1osTUFBSyxRQUNMLE9BQU9oQixVQUNQLE1BQUssWUFDTCxVQUFVLENBQUM7QUFBQSxVQUFFeUI7QUFBQUEsUUFBTyxNQUFNeEIsWUFBWXdCLE9BQU9DLEtBQUssS0FMcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtzRDtBQUFBLFdBUHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSTtBQUFBO0FBQUEsUUFFSCx1QkFBQyxXQUNDLGVBQVksWUFDWixNQUFLLFlBQ0wsT0FBT3hCLFVBQ1AsTUFBSyxZQUNMLFVBQVUsQ0FBQztBQUFBLFVBQUV1QjtBQUFBQSxRQUFPLE1BQU10QixZQUFZc0IsT0FBT0MsS0FBSyxLQUxwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS3NEO0FBQUEsV0FQeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFDQSx1QkFBQyxZQUFPLGVBQVksZUFBYyxNQUFLLFVBQVMscUJBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUQ7QUFBQSxTQXJCdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNCQTtBQUFBLE9BekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwQkE7QUFHRixRQUFNQyxVQUFXQyxhQUFZO0FBQzNCL0IsYUFBU0QsTUFBTWlDLE9BQU9ELE9BQU8sQ0FBQztBQUFBLEVBQ2hDO0FBRUEsUUFBTUUsUUFBUUEsTUFBTTtBQUNsQkMsWUFBUUMsSUFBSXBDLEtBQUs7QUFBQSxFQUNuQjtBQUVBLFFBQU1xQyxTQUFTQSxNQUFNO0FBQUEsRUFFckI7QUFFQSxRQUFNQyxhQUFhQSxDQUFDQyxJQUFJUCxZQUFZO0FBQ2xDLFVBQU1RLFdBQVc7QUFDakIsYUFBU0MsSUFBSSxHQUFHQSxJQUFJekMsTUFBTTBDLFFBQVFELEtBQUs7QUFDckMsVUFBSXpDLE1BQU11QyxPQUFPQSxJQUFJO0FBQ25CQyxpQkFBU0csS0FBS1gsT0FBTztBQUFBLE1BQ3ZCLE9BQU87QUFDTFEsaUJBQVNHLEtBQUszQyxNQUFNeUMsQ0FBQyxDQUFDO0FBQUEsTUFDeEI7QUFBQSxJQUNGO0FBQ0F4QyxhQUFTdUMsUUFBUTtBQUFBLEVBQ25CO0FBRUEsUUFBTUksYUFBY0wsUUFBTztBQUN6QixVQUFNQyxXQUFXeEMsTUFBTTZDLE9BQU9DLFVBQVFBLEtBQUtQLE9BQU9BLEVBQUU7QUFDcER0QyxhQUFTdUMsUUFBUTtBQUFBLEVBQ25CO0FBRUEsU0FDRSx1QkFBQyxTQUNFaEMsbUJBQVMsT0FDUm9CLFVBQVUsSUFFVix1QkFBQyxTQUNDO0FBQUEsMkJBQUMsU0FBTSxPQUFjLE1BQVksU0FBa0IsWUFBd0IsY0FBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrRztBQUFBLElBQ2xHLHVCQUFDLFdBQVMsT0FBYyxVQUFvQixNQUFZLFdBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUU7QUFBQSxPQUYzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBR0EsS0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBWUE7QUFFSjtBQUFDN0IsR0F2SEtELEtBQUc7QUFBQWlELEtBQUhqRDtBQXlITjtBQUFDO0FBY0QsZUFBZUE7QUFBRyxJQUFBaUQ7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiQmxvZ3MiLCJBZGRCbG9nIiwiYmxvZ1NlcnZpY2UiLCJsb2dpblNlcnZpY2UiLCJBcHAiLCJfcyIsImJsb2dzIiwic2V0QmxvZ3MiLCJlcnJvck1lc3NhZ2UiLCJzZXRFcnJvck1lc3NhZ2UiLCJ1c2VybmFtZSIsInNldFVzZXJuYW1lIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsInVzZXIiLCJzZXRVc2VyIiwibG9nZ2VkVXNlciIsIndpbmRvdyIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJKU09OIiwicGFyc2UiLCJzZXRUb2tlbiIsInRva2VuIiwiZ2V0QWxsIiwidGhlbiIsImhhbmRsZUxvZ2luIiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsImxvZ2luIiwic2V0SXRlbSIsInN0cmluZ2lmeSIsImV4Y2VwdGlvbiIsInNldFRpbWVvdXQiLCJsb2dpbkZvcm0iLCJ0YXJnZXQiLCJ2YWx1ZSIsImFkZEJsb2ciLCJuZXdCbG9nIiwiY29uY2F0IiwidGVzdGkiLCJjb25zb2xlIiwibG9nIiwibG9nT3V0IiwidXBkYXRlQmxvZyIsImlkIiwibmV3QmxvZ3MiLCJ4IiwibGVuZ3RoIiwicHVzaCIsImRlbGV0ZUJsb2ciLCJmaWx0ZXIiLCJibG9nIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHAuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IEJsb2dzIGZyb20gJy4vY29tcG9uZW50cy9CbG9ncydcclxuaW1wb3J0IEFkZEJsb2cgZnJvbSAnLi9jb21wb25lbnRzL0FkZEJsb2cnXHJcbmltcG9ydCBibG9nU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2Jsb2dzJ1xyXG5pbXBvcnQgbG9naW5TZXJ2aWNlIGZyb20gJy4vc2VydmljZXMvbG9naW4nXHJcblxyXG5cclxuXHJcbmNvbnN0IEFwcCA9ICgpID0+IHtcclxuICBjb25zdCBbYmxvZ3MsIHNldEJsb2dzXSA9IHVzZVN0YXRlKFtdKVxyXG4gIGNvbnN0IFtlcnJvck1lc3NhZ2UsIHNldEVycm9yTWVzc2FnZV0gPSB1c2VTdGF0ZShudWxsKVxyXG4gIGNvbnN0IFt1c2VybmFtZSwgc2V0VXNlcm5hbWVdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbdXNlciwgc2V0VXNlcl0gPSB1c2VTdGF0ZShudWxsKVxyXG5cclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGxvZ2dlZFVzZXIgPSB3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3VzZXInKVxyXG4gICAgaWYgKGxvZ2dlZFVzZXIpIHtcclxuICAgICAgY29uc3QgdXNlciA9IEpTT04ucGFyc2UobG9nZ2VkVXNlcilcclxuICAgICAgc2V0VXNlcih1c2VyKVxyXG4gICAgICBibG9nU2VydmljZS5zZXRUb2tlbih1c2VyLnRva2VuKVxyXG4gICAgfVxyXG4gIH0sW10pXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBibG9nU2VydmljZS5nZXRBbGwoKS50aGVuKGJsb2dzID0+XHJcbiAgICAgIHNldEJsb2dzKCBibG9ncyApXHJcbiAgICApXHJcbiAgfSwgW10pXHJcblxyXG4gIGNvbnN0IGhhbmRsZUxvZ2luID0gYXN5bmMgKGV2ZW50KSA9PiB7XHJcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgdXNlciA9IGF3YWl0IGxvZ2luU2VydmljZS5sb2dpbih7XHJcbiAgICAgICAgdXNlcm5hbWUsIHBhc3N3b3JkLFxyXG4gICAgICB9KVxyXG4gICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oXHJcbiAgICAgICAgJ3VzZXInLCBKU09OLnN0cmluZ2lmeSh1c2VyKVxyXG4gICAgICApXHJcbiAgICAgIGJsb2dTZXJ2aWNlLnNldFRva2VuKHVzZXIudG9rZW4pXHJcbiAgICAgIHNldFVzZXIodXNlcilcclxuICAgICAgc2V0VXNlcm5hbWUoJycpXHJcbiAgICAgIHNldFBhc3N3b3JkKCcnKVxyXG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XHJcbiAgICAgIHNldEVycm9yTWVzc2FnZSgnd3JvbmcgdXNlcm5hbWUgb3IgcGFzc3dvcmQnKVxyXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICBzZXRFcnJvck1lc3NhZ2UobnVsbClcclxuICAgICAgfSwgNTAwMClcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGNvbnN0IGxvZ2luRm9ybSA9ICgpID0+IChcclxuICAgIDxkaXY+XHJcbiAgICAgIDxoMj5sb2cgaW4gdG8gYXBwbGljYXRpb248L2gyPlxyXG4gICAgICA8aDIgY2xhc3NOYW1lPVwiZXJyb3JtZXNzYWdlXCI+e2Vycm9yTWVzc2FnZX08L2gyPlxyXG4gICAgICA8Zm9ybSBkYXRhLXRlc3RpZD0nbG9naW5mb3JtJyBvblN1Ym1pdD17aGFuZGxlTG9naW59PlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgdXNlcm5hbWVcclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICBkYXRhLXRlc3RpZD0ndXNlcm5hbWUnXHJcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgdmFsdWU9e3VzZXJuYW1lfVxyXG4gICAgICAgICAgICBuYW1lPVwiVXNlcm5hbWVcIlxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFVzZXJuYW1lKHRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgcGFzc3dvcmRcclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICBkYXRhLXRlc3RpZD0ncGFzc3dvcmQnXHJcbiAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cclxuICAgICAgICAgICAgbmFtZT1cIlBhc3N3b3JkXCJcclxuICAgICAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRQYXNzd29yZCh0YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8YnV0dG9uIGRhdGEtdGVzdGlkPSdsb2dpbmJ1dHRvbicgdHlwZT1cInN1Ym1pdFwiPmxvZ2luPC9idXR0b24+XHJcbiAgICAgIDwvZm9ybT5cclxuICAgIDwvZGl2PlxyXG4gIClcclxuXHJcbiAgY29uc3QgYWRkQmxvZyA9IChuZXdCbG9nKSA9PiB7XHJcbiAgICBzZXRCbG9ncyhibG9ncy5jb25jYXQobmV3QmxvZykpXHJcbiAgfVxyXG5cclxuICBjb25zdCB0ZXN0aSA9ICgpID0+IHtcclxuICAgIGNvbnNvbGUubG9nKGJsb2dzKVxyXG4gIH1cclxuXHJcbiAgY29uc3QgbG9nT3V0ID0gKCkgPT4ge1xyXG5cclxuICB9XHJcblxyXG4gIGNvbnN0IHVwZGF0ZUJsb2cgPSAoaWQsIG5ld0Jsb2cpID0+IHtcclxuICAgIGNvbnN0IG5ld0Jsb2dzID0gW11cclxuICAgIGZvciAobGV0IHggPSAwOyB4IDwgYmxvZ3MubGVuZ3RoOyB4KyspIHtcclxuICAgICAgaWYgKGJsb2dzLmlkID09PSBpZCkge1xyXG4gICAgICAgIG5ld0Jsb2dzLnB1c2gobmV3QmxvZylcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBuZXdCbG9ncy5wdXNoKGJsb2dzW3hdKVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBzZXRCbG9ncyhuZXdCbG9ncylcclxuICB9XHJcblxyXG4gIGNvbnN0IGRlbGV0ZUJsb2cgPSAoaWQpID0+IHtcclxuICAgIGNvbnN0IG5ld0Jsb2dzID0gYmxvZ3MuZmlsdGVyKGJsb2cgPT4gYmxvZy5pZCAhPT0gaWQpXHJcbiAgICBzZXRCbG9ncyhuZXdCbG9ncylcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICB7dXNlciA9PT0gbnVsbCA/IChcclxuICAgICAgICBsb2dpbkZvcm0oKVxyXG4gICAgICApIDogKFxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8QmxvZ3MgYmxvZ3M9e2Jsb2dzfSB1c2VyPXt1c2VyfSBzZXRVc2VyPXtzZXRVc2VyfSB1cGRhdGVCbG9nPXt1cGRhdGVCbG9nfSBkZWxldGVCbG9nPXtkZWxldGVCbG9nfS8+XHJcbiAgICAgICAgICA8QWRkQmxvZyAgYmxvZ3M9e2Jsb2dzfSBzZXRCbG9ncz17c2V0QmxvZ3N9IHVzZXI9e3VzZXJ9IGFkZEJsb2c9e2FkZEJsb2d9Lz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHsvKjxidXR0b24gb25DbGljaz17KCkgPT4gdGVzdGkoKX0+dGVzdGk8L2J1dHRvbj4qL31cclxuXHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcbnsvKjxkaXY+XHJcbiAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGxvZ091dCgpfT5Mb2cgb3V0PC9idXR0b24+XHJcbiAgICAgICAgICA8aDI+YmxvZ3M8L2gyPlxyXG4gICAgICAgICAgPHA+e3VzZXIudXNlcm5hbWV9IGhhcyBsb2dnZWQgaW48L3A+XHJcbiAgICAgICAgICB7YmxvZ3MubWFwKGJsb2cgPT4ge1xyXG4gICAgICAgICAgICBpZihibG9nLnVzZXIpIHtcclxuICAgICAgICAgICAgICBpZiAodXNlci51c2VybmFtZSA9PT0gYmxvZy51c2VyLnVzZXJuYW1lKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gPHAga2V5PXtibG9nLmlkfT57YmxvZy50aXRsZX0ge2Jsb2cuYXV0aG9yfSA8L3A+XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiBudWxsXHJcbiAgICAgICAgICB9KX1cclxuICAgICAgICA8L2Rpdj4qL31cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEFwcCJdLCJmaWxlIjoiQzovVXNlcnMvYWxleF8vRGVza3RvcC9GdWxsc3RhY2tvcGVuL29zYTUvYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL0FwcC5qc3gifQ==