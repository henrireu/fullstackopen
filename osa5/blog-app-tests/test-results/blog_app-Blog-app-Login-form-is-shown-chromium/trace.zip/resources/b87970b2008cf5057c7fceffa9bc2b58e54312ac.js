import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/main.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/main.css"
const __vite__css = ".newblog {\r\n    display: flex;\r\n    flex-direction: column;\r\n}\r\n\r\nbutton {\r\n    width: 70px;\r\n    height: 30px;\r\n}\r\n\r\n.errormessage {\r\n    color: red;\r\n}\r\n\r\n.message {\r\n    color: green;\r\n}\r\n\r\np {\r\n    margin-top: 3px;\r\n    margin-bottom: 3px;\r\n}\r\n\r\n.box {\r\n    margin-top: 4px;\r\n    border: solid black;\r\n}"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
export default __vite__css
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))