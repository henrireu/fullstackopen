import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AddBlog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d4a61334"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/AddBlog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=d4a61334"; const useState = __vite__cjsImport3_react["useState"];
import GetUserId from "/src/services/users.js";
import blogService from "/src/services/blogs.js";
const AddBlog = ({
  blogs,
  setBlogs,
  user,
  addBlog
}) => {
  _s();
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [url, setUrl] = useState("");
  const [message, setMessage] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const handleCreate = async (event) => {
    event.preventDefault();
    try {
      const userId = await GetUserId(user.username);
      const newBlog = {
        title,
        author,
        url,
        userId
      };
      blogService.create(newBlog);
      console.log(newBlog);
      addBlog(newBlog);
      setMessage("a new blog " + title + " by " + author);
      setTitle("");
      setAuthor("");
      setUrl("");
      setShowForm(false);
      setTimeout(() => {
        setMessage(null);
      }, 5e3);
    } catch (error) {
      console.error("Error creating blog:", error);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "message", children: message }, void 0, false, {
      fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
      lineNumber: 44,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("h2", { children: "create new" }, void 0, false, {
      fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
      lineNumber: 45,
      columnNumber: 7
    }, this),
    !showForm ? /* @__PURE__ */ jsxDEV("button", { style: {
      height: "40px"
    }, onClick: () => setShowForm(true), "data-testid": "newblog", children: "New blog" }, void 0, false, {
      fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
      lineNumber: 46,
      columnNumber: 20
    }, this) : /* @__PURE__ */ jsxDEV("form", { onSubmit: handleCreate, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "newblog", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          "title: ",
          /* @__PURE__ */ jsxDEV("input", { "data-testid": "title", type: "text", value: title, name: "Title", onChange: ({
            target
          }) => setTitle(target.value) }, void 0, false, {
            fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
            lineNumber: 51,
            columnNumber: 22
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
          lineNumber: 50,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          "author: ",
          /* @__PURE__ */ jsxDEV("input", { "data-testid": "author", type: "text", value: author, name: "Author", onChange: ({
            target
          }) => setAuthor(target.value) }, void 0, false, {
            fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
            lineNumber: 56,
            columnNumber: 23
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
          lineNumber: 55,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          "url: ",
          /* @__PURE__ */ jsxDEV("input", { "data-testid": "url", type: "text", value: url, name: "Url", onChange: ({
            target
          }) => setUrl(target.value) }, void 0, false, {
            fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
            lineNumber: 61,
            columnNumber: 20
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
          lineNumber: 60,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
        lineNumber: 49,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("button", { "data-testid": "create", type: "submit", children: "create" }, void 0, false, {
        fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
        lineNumber: 66,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: () => setShowForm(false), children: "Takaisin" }, void 0, false, {
        fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
        lineNumber: 67,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
      lineNumber: 48,
      columnNumber: 84
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/AddBlog.jsx",
    lineNumber: 43,
    columnNumber: 10
  }, this);
};
_s(AddBlog, "mbBExPI2f0UjBBUY3eZT43WdQsQ=");
_c = AddBlog;
export default AddBlog;
var _c;
$RefreshReg$(_c, "AddBlog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/AddBlog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMENNOzs7Ozs7Ozs7Ozs7Ozs7OztBQTFDTixTQUFTQSxnQkFBZ0I7QUFDekIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxpQkFBaUI7QUFFeEIsTUFBTUMsVUFBVUEsQ0FBQztBQUFBLEVBQUVDO0FBQUFBLEVBQU9DO0FBQUFBLEVBQVVDO0FBQUFBLEVBQU1DO0FBQVEsTUFBTTtBQUFBQyxLQUFBO0FBQ3RELFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJVixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDVyxRQUFRQyxTQUFTLElBQUlaLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNhLEtBQUtDLE1BQU0sSUFBSWQsU0FBUyxFQUFFO0FBQ2pDLFFBQU0sQ0FBQ2UsU0FBU0MsVUFBVSxJQUFJaEIsU0FBUyxJQUFJO0FBRTNDLFFBQU0sQ0FBQ2lCLFVBQVVDLFdBQVcsSUFBSWxCLFNBQVMsS0FBSztBQUU5QyxRQUFNbUIsZUFBZSxPQUFPQyxVQUFVO0FBQ3BDQSxVQUFNQyxlQUFlO0FBQ3JCLFFBQUk7QUFDRixZQUFNQyxTQUFTLE1BQU1yQixVQUFVSyxLQUFLaUIsUUFBUTtBQUM1QyxZQUFNQyxVQUFVO0FBQUEsUUFDZGY7QUFBQUEsUUFDQUU7QUFBQUEsUUFDQUU7QUFBQUEsUUFDQVM7QUFBQUEsTUFDRjtBQUNBcEIsa0JBQVl1QixPQUFPRCxPQUFPO0FBQzFCRSxjQUFRQyxJQUFJSCxPQUFPO0FBRW5CakIsY0FBUWlCLE9BQU87QUFFZlIsaUJBQVcsZ0JBQWdCUCxRQUFRLFNBQVNFLE1BQU07QUFDbERELGVBQVMsRUFBRTtBQUNYRSxnQkFBVSxFQUFFO0FBQ1pFLGFBQU8sRUFBRTtBQUNUSSxrQkFBWSxLQUFLO0FBQ2pCVSxpQkFBVyxNQUFNO0FBQ2ZaLG1CQUFXLElBQUk7QUFBQSxNQUNqQixHQUFHLEdBQUk7QUFBQSxJQUNULFNBQVNhLE9BQU87QUFDZEgsY0FBUUcsTUFBTSx3QkFBd0JBLEtBQUs7QUFBQSxJQUM3QztBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxRQUFHLFdBQVUsV0FBV2QscUJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUM7QUFBQSxJQUNqQyx1QkFBQyxRQUFHLDBCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYztBQUFBLElBQ2IsQ0FBQ0UsV0FDQSx1QkFBQyxZQUFPLE9BQU87QUFBQSxNQUFFYSxRQUFRO0FBQUEsSUFBTyxHQUFHLFNBQVMsTUFBTVosWUFBWSxJQUFJLEdBQUcsZUFBWSxXQUFVLHdCQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1HLElBRW5HLHVCQUFDLFVBQUssVUFBVUMsY0FDZDtBQUFBLDZCQUFDLFNBQUksV0FBVSxXQUNiO0FBQUEsK0JBQUMsU0FBSTtBQUFBO0FBQUEsVUFDSSx1QkFBQyxXQUNOLGVBQVksU0FDWixNQUFPLFFBQ1AsT0FBU1YsT0FDVCxNQUFPLFNBQ1AsVUFBWSxDQUFDO0FBQUEsWUFBRXNCO0FBQUFBLFVBQU8sTUFBTXJCLFNBQVNxQixPQUFPQyxLQUFLLEtBTDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSzhDO0FBQUEsYUFOdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFDQSx1QkFBQyxTQUFJO0FBQUE7QUFBQSxVQUNLLHVCQUFDLFdBQ1AsZUFBWSxVQUNaLE1BQU8sUUFDUCxPQUFTckIsUUFDVCxNQUFPLFVBQ1AsVUFBWSxDQUFDO0FBQUEsWUFBRW9CO0FBQUFBLFVBQU8sTUFBTW5CLFVBQVVtQixPQUFPQyxLQUFLLEtBTDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSzhDO0FBQUEsYUFOeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFDQSx1QkFBQyxTQUFJO0FBQUE7QUFBQSxVQUNFLHVCQUFDLFdBQ0osZUFBWSxPQUNaLE1BQU8sUUFDUCxPQUFTbkIsS0FDVCxNQUFPLE9BQ1AsVUFBWSxDQUFDO0FBQUEsWUFBRWtCO0FBQUFBLFVBQU8sTUFBTWpCLE9BQU9pQixPQUFPQyxLQUFLLEtBTDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSzhDO0FBQUEsYUFOckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsV0EzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTRCQTtBQUFBLE1BQ0EsdUJBQUMsWUFBTyxlQUFZLFVBQVMsTUFBSyxVQUFTLHNCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlEO0FBQUEsTUFDakQsdUJBQUMsWUFBTyxTQUFTLE1BQU1kLFlBQVksS0FBSyxHQUFHLHdCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1EO0FBQUEsU0EvQnJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQ0E7QUFBQSxPQXRDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd0NBO0FBRUo7QUFBQ1YsR0EvRUtMLFNBQU87QUFBQThCLEtBQVA5QjtBQWlGTixlQUFlQTtBQUFPLElBQUE4QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJHZXRVc2VySWQiLCJibG9nU2VydmljZSIsIkFkZEJsb2ciLCJibG9ncyIsInNldEJsb2dzIiwidXNlciIsImFkZEJsb2ciLCJfcyIsInRpdGxlIiwic2V0VGl0bGUiLCJhdXRob3IiLCJzZXRBdXRob3IiLCJ1cmwiLCJzZXRVcmwiLCJtZXNzYWdlIiwic2V0TWVzc2FnZSIsInNob3dGb3JtIiwic2V0U2hvd0Zvcm0iLCJoYW5kbGVDcmVhdGUiLCJldmVudCIsInByZXZlbnREZWZhdWx0IiwidXNlcklkIiwidXNlcm5hbWUiLCJuZXdCbG9nIiwiY3JlYXRlIiwiY29uc29sZSIsImxvZyIsInNldFRpbWVvdXQiLCJlcnJvciIsImhlaWdodCIsInRhcmdldCIsInZhbHVlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBZGRCbG9nLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgR2V0VXNlcklkIGZyb20gJy4uL3NlcnZpY2VzL3VzZXJzJ1xyXG5pbXBvcnQgYmxvZ1NlcnZpY2UgZnJvbSAnLi4vc2VydmljZXMvYmxvZ3MnXHJcblxyXG5jb25zdCBBZGRCbG9nID0gKHsgYmxvZ3MgLHNldEJsb2dzLCB1c2VyLCBhZGRCbG9nIH0pID0+IHtcclxuICBjb25zdCBbdGl0bGUsIHNldFRpdGxlXSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFthdXRob3IsIHNldEF1dGhvcl0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbdXJsLCBzZXRVcmxdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUobnVsbClcclxuXHJcbiAgY29uc3QgW3Nob3dGb3JtLCBzZXRTaG93Rm9ybV0gPSB1c2VTdGF0ZShmYWxzZSlcclxuXHJcbiAgY29uc3QgaGFuZGxlQ3JlYXRlID0gYXN5bmMgKGV2ZW50KSA9PiB7XHJcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCB1c2VySWQgPSBhd2FpdCBHZXRVc2VySWQodXNlci51c2VybmFtZSlcclxuICAgICAgY29uc3QgbmV3QmxvZyA9IHtcclxuICAgICAgICB0aXRsZTogdGl0bGUsXHJcbiAgICAgICAgYXV0aG9yOiBhdXRob3IsXHJcbiAgICAgICAgdXJsOiB1cmwsXHJcbiAgICAgICAgdXNlcklkOiB1c2VySWRcclxuICAgICAgfVxyXG4gICAgICBibG9nU2VydmljZS5jcmVhdGUobmV3QmxvZylcclxuICAgICAgY29uc29sZS5sb2cobmV3QmxvZylcclxuICAgICAgLy9zZXRCbG9ncyhibG9ncy5jb25jYXQobmV3QmxvZykpXHJcbiAgICAgIGFkZEJsb2cobmV3QmxvZylcclxuXHJcbiAgICAgIHNldE1lc3NhZ2UoJ2EgbmV3IGJsb2cgJyArIHRpdGxlICsgJyBieSAnICsgYXV0aG9yKVxyXG4gICAgICBzZXRUaXRsZSgnJylcclxuICAgICAgc2V0QXV0aG9yKCcnKVxyXG4gICAgICBzZXRVcmwoJycpXHJcbiAgICAgIHNldFNob3dGb3JtKGZhbHNlKVxyXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICBzZXRNZXNzYWdlKG51bGwpXHJcbiAgICAgIH0sIDUwMDApXHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBjcmVhdGluZyBibG9nOicsIGVycm9yKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIDxoMiBjbGFzc05hbWU9XCJtZXNzYWdlXCI+e21lc3NhZ2V9PC9oMj5cclxuICAgICAgPGgyPmNyZWF0ZSBuZXc8L2gyPlxyXG4gICAgICB7IXNob3dGb3JtID8gKFxyXG4gICAgICAgIDxidXR0b24gc3R5bGU9e3sgaGVpZ2h0OiAnNDBweCcgfX0gb25DbGljaz17KCkgPT4gc2V0U2hvd0Zvcm0odHJ1ZSl9IGRhdGEtdGVzdGlkPSduZXdibG9nJz5OZXcgYmxvZzwvYnV0dG9uPlxyXG4gICAgICApIDogKFxyXG4gICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVDcmVhdGV9PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJuZXdibG9nXCI+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgdGl0bGU6IDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgZGF0YS10ZXN0aWQ9J3RpdGxlJ1xyXG4gICAgICAgICAgICAgICAgdHlwZSA9ICd0ZXh0J1xyXG4gICAgICAgICAgICAgICAgdmFsdWUgPSB7dGl0bGV9XHJcbiAgICAgICAgICAgICAgICBuYW1lID0gJ1RpdGxlJ1xyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2UgPSB7KHsgdGFyZ2V0IH0pID0+IHNldFRpdGxlKHRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgYXV0aG9yOiA8aW5wdXRcclxuICAgICAgICAgICAgICAgIGRhdGEtdGVzdGlkPSdhdXRob3InXHJcbiAgICAgICAgICAgICAgICB0eXBlID0gJ3RleHQnXHJcbiAgICAgICAgICAgICAgICB2YWx1ZSA9IHthdXRob3J9XHJcbiAgICAgICAgICAgICAgICBuYW1lID0gJ0F1dGhvcidcclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlID0geyh7IHRhcmdldCB9KSA9PiBzZXRBdXRob3IodGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICB1cmw6IDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgZGF0YS10ZXN0aWQ9J3VybCdcclxuICAgICAgICAgICAgICAgIHR5cGUgPSAndGV4dCdcclxuICAgICAgICAgICAgICAgIHZhbHVlID0ge3VybH1cclxuICAgICAgICAgICAgICAgIG5hbWUgPSAnVXJsJ1xyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2UgPSB7KHsgdGFyZ2V0IH0pID0+IHNldFVybCh0YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8YnV0dG9uIGRhdGEtdGVzdGlkPSdjcmVhdGUnIHR5cGU9XCJzdWJtaXRcIj5jcmVhdGU8L2J1dHRvbj5cclxuICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0U2hvd0Zvcm0oZmFsc2UpfT5UYWthaXNpbjwvYnV0dG9uPlxyXG4gICAgICAgIDwvZm9ybT5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQWRkQmxvZyJdLCJmaWxlIjoiQzovVXNlcnMvYWxleF8vRGVza3RvcC9GdWxsc3RhY2tvcGVuL29zYTUvYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQWRkQmxvZy5qc3gifQ==