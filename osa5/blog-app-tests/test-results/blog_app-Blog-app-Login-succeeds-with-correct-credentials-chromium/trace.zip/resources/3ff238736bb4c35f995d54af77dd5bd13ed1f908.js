import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d4a61334"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/Blog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=d4a61334"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import blogservice from "/src/services/blogs.js";
import __vite__cjsImport5_propTypes from "/node_modules/.vite/deps/prop-types.js?v=d4a61334"; const PropTypes = __vite__cjsImport5_propTypes.__esModule ? __vite__cjsImport5_propTypes.default : __vite__cjsImport5_propTypes;
const Blog = ({
  blog,
  user,
  deleteBlog
}) => {
  _s();
  const [showAll, setShowAll] = useState(false);
  const [thisblog, setThisBlog] = useState();
  useEffect(() => {
    setThisBlog(blog);
  }, [blog]);
  const handleLike = async () => {
    const newBlog = {
      ...thisblog,
      likes: thisblog.likes + 1
    };
    setThisBlog(newBlog);
    await blogservice.update(blog.id, newBlog);
  };
  const handleRemove = async () => {
    if (window.confirm("are you sure you want to delete " + thisblog.title)) {
      await blogservice.deleteBlog(thisblog.id);
      deleteBlog(thisblog.id);
      setThisBlog();
    }
  };
  if (!thisblog) {
    return /* @__PURE__ */ jsxDEV(Fragment, {}, void 0, false, {
      fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 38,
      columnNumber: 12
    }, this);
  }
  if (showAll) {
    return /* @__PURE__ */ jsxDEV("div", { className: "box", children: [
      thisblog.title,
      " ",
      thisblog.author,
      /* @__PURE__ */ jsxDEV("button", { style: {
        height: "20px"
      }, onClick: () => setShowAll(false), children: "hide" }, void 0, false, {
        fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 43,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "peet", style: {
        display: "flex",
        flexDirection: "column"
      }, children: [
        /* @__PURE__ */ jsxDEV("p", { children: blog.url }, void 0, false, {
          fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/Blog.jsx",
          lineNumber: 50,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          thisblog.likes.toString(),
          /* @__PURE__ */ jsxDEV("button", { "data-testid": "like", id: "like", onClick: handleLike, children: "like" }, void 0, false, {
            fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/Blog.jsx",
            lineNumber: 51,
            columnNumber: 41
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/Blog.jsx",
          lineNumber: 51,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: blog.user.username }, void 0, false, {
          fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/Blog.jsx",
          lineNumber: 52,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 46,
        columnNumber: 9
      }, this),
      blog.user.username === user.username && /* @__PURE__ */ jsxDEV("button", { onClick: handleRemove, children: "remove" }, void 0, false, {
        fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 54,
        columnNumber: 50
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 41,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "box", children: [
    blog.title,
    " ",
    blog.author,
    /* @__PURE__ */ jsxDEV("button", { "data-testid": "show", id: "show", style: {
      height: "20px"
    }, onClick: () => setShowAll(true), children: "show" }, void 0, false, {
      fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 59,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/Blog.jsx",
    lineNumber: 57,
    columnNumber: 10
  }, this);
};
_s(Blog, "BcHvLW7j1vK4kQ214wK37GejhrY=");
_c = Blog;
Blog.propTypes = {
  blog: PropTypes.object.isRequired,
  user: PropTypes.object.isRequired
};
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUM0Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFyQzVCLFNBQVNBLFVBQVVDLGlCQUFpQjtBQUNwQyxPQUFPQyxpQkFBaUI7QUFFeEIsT0FBT0MsZUFBZTtBQUV0QixNQUFNQyxPQUFPQSxDQUFDO0FBQUEsRUFBRUM7QUFBQUEsRUFBTUM7QUFBQUEsRUFBTUM7QUFBVyxNQUFNO0FBQUFDLEtBQUE7QUFDM0MsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUlWLFNBQVMsS0FBSztBQUM1QyxRQUFNLENBQUNXLFVBQVVDLFdBQVcsSUFBSVosU0FBUztBQUd6Q0MsWUFBVSxNQUFNO0FBQ2RXLGdCQUFZUCxJQUFJO0FBQUEsRUFDbEIsR0FBRSxDQUFDQSxJQUFJLENBQUM7QUFFUixRQUFNUSxhQUFhLFlBQVk7QUFDN0IsVUFBTUMsVUFBVTtBQUFBLE1BQ2QsR0FBR0g7QUFBQUEsTUFDSEksT0FBT0osU0FBU0ksUUFBUTtBQUFBLElBQzFCO0FBQ0FILGdCQUFZRSxPQUFPO0FBQ25CLFVBQU1aLFlBQVljLE9BQU9YLEtBQUtZLElBQUlILE9BQU87QUFBQSxFQUMzQztBQUVBLFFBQU1JLGVBQWUsWUFBWTtBQUMvQixRQUFJQyxPQUFPQyxRQUFRLHFDQUFxQ1QsU0FBU1UsS0FBSyxHQUFHO0FBT3ZFLFlBQU1uQixZQUFZSyxXQUFXSSxTQUFTTSxFQUFFO0FBQ3hDVixpQkFBV0ksU0FBU00sRUFBRTtBQUN0Qkwsa0JBQVk7QUFBQSxJQUNkO0FBQUEsRUFDRjtBQUVBLE1BQUksQ0FBQ0QsVUFBVTtBQUFFLFdBQVM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFFO0FBQUEsRUFBSTtBQUVoQyxNQUFJRixTQUFTO0FBQ1gsV0FDRSx1QkFBQyxTQUFJLFdBQVUsT0FDWkU7QUFBQUEsZUFBU1U7QUFBQUEsTUFBTTtBQUFBLE1BQUVWLFNBQVNXO0FBQUFBLE1BQzNCLHVCQUFDLFlBQU8sT0FBTztBQUFBLFFBQUVDLFFBQVE7QUFBQSxNQUFPLEdBQUcsU0FBUyxNQUFNYixXQUFXLEtBQUssR0FBRyxvQkFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RTtBQUFBLE1BQ3pFLHVCQUFDLFNBQUksV0FBVSxRQUFPLE9BQU87QUFBQSxRQUFFYyxTQUFTO0FBQUEsUUFBUUMsZUFBZTtBQUFBLE1BQVMsR0FDdEU7QUFBQSwrQkFBQyxPQUFHcEIsZUFBS3FCLE9BQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFhO0FBQUEsUUFDYix1QkFBQyxPQUFHZjtBQUFBQSxtQkFBU0ksTUFBTVksU0FBUztBQUFBLFVBQUUsdUJBQUMsWUFBTyxlQUFZLFFBQU8sSUFBRyxRQUFPLFNBQVNkLFlBQVksb0JBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThEO0FBQUEsYUFBNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRztBQUFBLFFBQ3JHLHVCQUFDLE9BQUdSLGVBQUtDLEtBQUtzQixZQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUI7QUFBQSxXQUh6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxNQUNDdkIsS0FBS0MsS0FBS3NCLGFBQWF0QixLQUFLc0IsWUFDM0IsdUJBQUMsWUFBTyxTQUFTVixjQUFjLHNCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFDO0FBQUEsU0FUekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsRUFFSjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLE9BQ1piO0FBQUFBLFNBQUtnQjtBQUFBQSxJQUFNO0FBQUEsSUFBRWhCLEtBQUtpQjtBQUFBQSxJQUNuQix1QkFBQyxZQUFPLGVBQVksUUFBTyxJQUFHLFFBQU8sT0FBTztBQUFBLE1BQUVDLFFBQVE7QUFBQSxJQUFPLEdBQUcsU0FBUyxNQUFNYixXQUFXLElBQUksR0FBRyxvQkFBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxRztBQUFBLE9BRnZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHQTtBQUVKO0FBQUNGLEdBekRLSixNQUFJO0FBQUF5QixLQUFKekI7QUEyRE5BLEtBQUswQixZQUFZO0FBQUEsRUFDZnpCLE1BQU1GLFVBQVU0QixPQUFPQztBQUFBQSxFQUN2QjFCLE1BQU1ILFVBQVU0QixPQUFPQztBQUN6QjtBQUVBLGVBQWU1QjtBQUFJLElBQUF5QjtBQUFBSSxhQUFBSixJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJibG9nc2VydmljZSIsIlByb3BUeXBlcyIsIkJsb2ciLCJibG9nIiwidXNlciIsImRlbGV0ZUJsb2ciLCJfcyIsInNob3dBbGwiLCJzZXRTaG93QWxsIiwidGhpc2Jsb2ciLCJzZXRUaGlzQmxvZyIsImhhbmRsZUxpa2UiLCJuZXdCbG9nIiwibGlrZXMiLCJ1cGRhdGUiLCJpZCIsImhhbmRsZVJlbW92ZSIsIndpbmRvdyIsImNvbmZpcm0iLCJ0aXRsZSIsImF1dGhvciIsImhlaWdodCIsImRpc3BsYXkiLCJmbGV4RGlyZWN0aW9uIiwidXJsIiwidG9TdHJpbmciLCJ1c2VybmFtZSIsIl9jIiwicHJvcFR5cGVzIiwib2JqZWN0IiwiaXNSZXF1aXJlZCIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkJsb2cuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IGJsb2dzZXJ2aWNlIGZyb20gJy4uL3NlcnZpY2VzL2Jsb2dzJ1xyXG5cclxuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJ1xyXG5cclxuY29uc3QgQmxvZyA9ICh7IGJsb2csIHVzZXIsIGRlbGV0ZUJsb2cgfSkgPT4ge1xyXG4gIGNvbnN0IFtzaG93QWxsLCBzZXRTaG93QWxsXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gIGNvbnN0IFt0aGlzYmxvZywgc2V0VGhpc0Jsb2ddID0gdXNlU3RhdGUoKVxyXG5cclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNldFRoaXNCbG9nKGJsb2cpXHJcbiAgfSxbYmxvZ10pXHJcblxyXG4gIGNvbnN0IGhhbmRsZUxpa2UgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCBuZXdCbG9nID0ge1xyXG4gICAgICAuLi50aGlzYmxvZyxcclxuICAgICAgbGlrZXM6IHRoaXNibG9nLmxpa2VzICsgMVxyXG4gICAgfVxyXG4gICAgc2V0VGhpc0Jsb2cobmV3QmxvZylcclxuICAgIGF3YWl0IGJsb2dzZXJ2aWNlLnVwZGF0ZShibG9nLmlkLCBuZXdCbG9nKVxyXG4gIH1cclxuXHJcbiAgY29uc3QgaGFuZGxlUmVtb3ZlID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKHdpbmRvdy5jb25maXJtKCdhcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gZGVsZXRlICcgKyB0aGlzYmxvZy50aXRsZSkpIHtcclxuICAgICAgLyp0cnkge1xyXG4gICAgICAgIGF3YWl0IGJsb2dzZXJ2aWNlLmRlbGV0ZUJsb2codGhpc2Jsb2cuaWQpXHJcbiAgICAgICAgc2V0VGhpc0Jsb2coKVxyXG4gICAgICB9IGNhdGNoIChlcnJvcil7XHJcbiAgICAgICAgdGhyb3cgZXJyb3JcclxuICAgICAgfSovXHJcbiAgICAgIGF3YWl0IGJsb2dzZXJ2aWNlLmRlbGV0ZUJsb2codGhpc2Jsb2cuaWQpXHJcbiAgICAgIGRlbGV0ZUJsb2codGhpc2Jsb2cuaWQpXHJcbiAgICAgIHNldFRoaXNCbG9nKClcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGlmICghdGhpc2Jsb2cpIHsgcmV0dXJuICggPD48Lz4pfVxyXG5cclxuICBpZiAoc2hvd0FsbCkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3hcIj5cclxuICAgICAgICB7dGhpc2Jsb2cudGl0bGV9IHt0aGlzYmxvZy5hdXRob3J9XHJcbiAgICAgICAgPGJ1dHRvbiBzdHlsZT17eyBoZWlnaHQ6ICcyMHB4JyB9fSBvbkNsaWNrPXsoKSA9PiBzZXRTaG93QWxsKGZhbHNlKX0+aGlkZTwvYnV0dG9uPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPSdwZWV0JyBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nIH19PlxyXG4gICAgICAgICAgPHA+e2Jsb2cudXJsfTwvcD5cclxuICAgICAgICAgIDxwPnt0aGlzYmxvZy5saWtlcy50b1N0cmluZygpfTxidXR0b24gZGF0YS10ZXN0aWQ9J2xpa2UnIGlkPSdsaWtlJyBvbkNsaWNrPXtoYW5kbGVMaWtlfT5saWtlPC9idXR0b24+PC9wPlxyXG4gICAgICAgICAgPHA+e2Jsb2cudXNlci51c2VybmFtZX08L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAge2Jsb2cudXNlci51c2VybmFtZSA9PT0gdXNlci51c2VybmFtZSAmJiAoXHJcbiAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e2hhbmRsZVJlbW92ZX0+cmVtb3ZlPC9idXR0b24+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICApXHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJib3hcIj5cclxuICAgICAge2Jsb2cudGl0bGV9IHtibG9nLmF1dGhvcn1cclxuICAgICAgPGJ1dHRvbiBkYXRhLXRlc3RpZD0nc2hvdycgaWQ9J3Nob3cnIHN0eWxlPXt7IGhlaWdodDogJzIwcHgnIH19IG9uQ2xpY2s9eygpID0+IHNldFNob3dBbGwodHJ1ZSl9PnNob3c8L2J1dHRvbj5cclxuICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG5cclxuQmxvZy5wcm9wVHlwZXMgPSB7XHJcbiAgYmxvZzogUHJvcFR5cGVzLm9iamVjdC5pc1JlcXVpcmVkLFxyXG4gIHVzZXI6IFByb3BUeXBlcy5vYmplY3QuaXNSZXF1aXJlZFxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBCbG9nIl0sImZpbGUiOiJDOi9Vc2Vycy9hbGV4Xy9EZXNrdG9wL0Z1bGxzdGFja29wZW4vb3NhNS9ibG9nbGlzdC1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9CbG9nLmpzeCJ9