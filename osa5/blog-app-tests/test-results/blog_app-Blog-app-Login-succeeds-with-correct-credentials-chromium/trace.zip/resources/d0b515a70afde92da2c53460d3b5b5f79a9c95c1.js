import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blogs.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d4a61334"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/Blogs.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=d4a61334"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import Blog from "/src/components/Blog.jsx?t=1715155774866";
const Blogs = ({
  blogs,
  user,
  setUser,
  deleteBlog
}) => {
  _s();
  const [thisBlogs, setThisBlogs] = useState([]);
  useEffect(() => {
    setThisBlogs(blogs);
  }, [blogs]);
  const addBlog = (blog) => {
    const newBlogs = thisBlogs.concat(blog);
    setThisBlogs(newBlogs);
  };
  const handleLogOut = () => {
    localStorage.removeItem("user");
    setUser(null);
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("button", { "data-testid": "logout", onClick: () => handleLogOut(), children: "Log out" }, void 0, false, {
      fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/Blogs.jsx",
      lineNumber: 24,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("h2", { children: "blogs" }, void 0, false, {
      fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/Blogs.jsx",
      lineNumber: 25,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: [
      user.name,
      " logged in"
    ] }, void 0, true, {
      fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/Blogs.jsx",
      lineNumber: 26,
      columnNumber: 7
    }, this),
    thisBlogs.sort((a, b) => b.likes - a.likes).map((blog) => {
      return /* @__PURE__ */ jsxDEV(Blog, { blog, user, deleteBlog }, blog.id, false, {
        fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/Blogs.jsx",
        lineNumber: 31,
        columnNumber: 14
      }, this);
    })
  ] }, void 0, true, {
    fileName: "C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/Blogs.jsx",
    lineNumber: 23,
    columnNumber: 10
  }, this);
};
_s(Blogs, "FHBc5LGdi+JMeydI9xRa2oTjd7o=");
_c = Blogs;
export default Blogs;
var _c;
$RefreshReg$(_c, "Blogs");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/alex_/Desktop/Fullstackopen/osa5/bloglist-frontend/src/components/Blogs.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0JNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXhCTixTQUFTQSxVQUFVQyxpQkFBaUI7QUFFcEMsT0FBT0MsVUFBVTtBQUdqQixNQUFNQyxRQUFRQSxDQUFDO0FBQUEsRUFBRUM7QUFBQUEsRUFBT0M7QUFBQUEsRUFBTUM7QUFBQUEsRUFBU0M7QUFBVyxNQUFNO0FBQUFDLEtBQUE7QUFDdEQsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUlWLFNBQVMsRUFBRTtBQUU3Q0MsWUFBVSxNQUFNO0FBQ2RTLGlCQUFhTixLQUFLO0FBQUEsRUFDcEIsR0FBRSxDQUFDQSxLQUFLLENBQUM7QUFFVCxRQUFNTyxVQUFXQyxVQUFTO0FBQ3hCLFVBQU1DLFdBQVdKLFVBQVVLLE9BQU9GLElBQUk7QUFDdENGLGlCQUFhRyxRQUFRO0FBQUEsRUFDdkI7QUFFQSxRQUFNRSxlQUFlQSxNQUFNO0FBQ3pCQyxpQkFBYUMsV0FBVyxNQUFNO0FBQzlCWCxZQUFRLElBQUk7QUFBQSxFQUNkO0FBRUEsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsWUFBTyxlQUFZLFVBQVMsU0FBUyxNQUFNUyxhQUFhLEdBQUcsdUJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUU7QUFBQSxJQUNuRSx1QkFBQyxRQUFHLHFCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUztBQUFBLElBQ1QsdUJBQUMsT0FBR1Y7QUFBQUEsV0FBS2E7QUFBQUEsTUFBSztBQUFBLFNBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3QjtBQUFBLElBQ3ZCVCxVQUFVVSxLQUFLLENBQUNDLEdBQUdDLE1BQU1BLEVBQUVDLFFBQVFGLEVBQUVFLEtBQUssRUFBRUMsSUFBSVgsVUFBUTtBQUl2RCxhQUFPLHVCQUFDLFFBQW1CLE1BQVksTUFBWSxjQUFqQ0EsS0FBS1ksSUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRTtBQUFBLElBRTVFLENBQUM7QUFBQSxPQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FXQTtBQUdKO0FBQUNoQixHQWhDS0wsT0FBSztBQUFBc0IsS0FBTHRCO0FBa0NOLGVBQWVBO0FBQUssSUFBQXNCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsIkJsb2ciLCJCbG9ncyIsImJsb2dzIiwidXNlciIsInNldFVzZXIiLCJkZWxldGVCbG9nIiwiX3MiLCJ0aGlzQmxvZ3MiLCJzZXRUaGlzQmxvZ3MiLCJhZGRCbG9nIiwiYmxvZyIsIm5ld0Jsb2dzIiwiY29uY2F0IiwiaGFuZGxlTG9nT3V0IiwibG9jYWxTdG9yYWdlIiwicmVtb3ZlSXRlbSIsIm5hbWUiLCJzb3J0IiwiYSIsImIiLCJsaWtlcyIsIm1hcCIsImlkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJCbG9ncy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xyXG5cclxuaW1wb3J0IEJsb2cgZnJvbSAnLi9CbG9nJ1xyXG5cclxuXHJcbmNvbnN0IEJsb2dzID0gKHsgYmxvZ3MsIHVzZXIsIHNldFVzZXIsIGRlbGV0ZUJsb2cgfSkgPT4ge1xyXG4gIGNvbnN0IFt0aGlzQmxvZ3MsIHNldFRoaXNCbG9nc10gPSB1c2VTdGF0ZShbXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNldFRoaXNCbG9ncyhibG9ncylcclxuICB9LFtibG9nc10pXHJcblxyXG4gIGNvbnN0IGFkZEJsb2cgPSAoYmxvZykgPT4ge1xyXG4gICAgY29uc3QgbmV3QmxvZ3MgPSB0aGlzQmxvZ3MuY29uY2F0KGJsb2cpXHJcbiAgICBzZXRUaGlzQmxvZ3MobmV3QmxvZ3MpXHJcbiAgfVxyXG5cclxuICBjb25zdCBoYW5kbGVMb2dPdXQgPSAoKSA9PiB7XHJcbiAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgndXNlcicpXHJcbiAgICBzZXRVc2VyKG51bGwpXHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAgPGJ1dHRvbiBkYXRhLXRlc3RpZD0nbG9nb3V0JyBvbkNsaWNrPXsoKSA9PiBoYW5kbGVMb2dPdXQoKX0+TG9nIG91dDwvYnV0dG9uPlxyXG4gICAgICA8aDI+YmxvZ3M8L2gyPlxyXG4gICAgICA8cD57dXNlci5uYW1lfSBsb2dnZWQgaW48L3A+XHJcbiAgICAgIHt0aGlzQmxvZ3Muc29ydCgoYSwgYikgPT4gYi5saWtlcyAtIGEubGlrZXMpLm1hcChibG9nID0+IHtcclxuICAgICAgICAvKmlmKGJsb2cudXNlcikge1xyXG4gICAgICAgICAgcmV0dXJuIDxCbG9nIGtleT17YmxvZy5pZH0gYmxvZz17YmxvZ30gdXNlcj17dXNlcn0gZGVsZXRlQmxvZz17ZGVsZXRlQmxvZ30vPlxyXG4gICAgICAgIH0qL1xyXG4gICAgICAgIHJldHVybiA8QmxvZyBrZXk9e2Jsb2cuaWR9IGJsb2c9e2Jsb2d9IHVzZXI9e3VzZXJ9IGRlbGV0ZUJsb2c9e2RlbGV0ZUJsb2d9Lz5cclxuICAgICAgICAvL3JldHVybiBudWxsXHJcbiAgICAgIH0pfVxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG5cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQmxvZ3MiXSwiZmlsZSI6IkM6L1VzZXJzL2FsZXhfL0Rlc2t0b3AvRnVsbHN0YWNrb3Blbi9vc2E1L2Jsb2dsaXN0LWZyb250ZW5kL3NyYy9jb21wb25lbnRzL0Jsb2dzLmpzeCJ9